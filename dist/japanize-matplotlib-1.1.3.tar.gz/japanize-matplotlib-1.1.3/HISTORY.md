## 1.0.5 (2019-09-08)
[#4](https://github.com/uehara1414/japanize-matplotlib/pull/4) pathlib に対応していない環境下で動作しない不具合を修正 ([@elnikkis](https://github.com/elnikkis))

## 1.1.0 (2020-05-03)
[#9](https://github.com/uehara1414/japanize-matplotlib/pull/9) import時に加えてjapanizeメソッドを実行した際にもフォントが有効化されるよう機能追加 ([@vaaaaanquish](https://github.com/vaaaaanquish))

## 1.1.1 (2020-05-03)
READMEにFAQを追加

## 1.1.2 (2020-05-04)
記憶にない・・・

## 1.1.3 (2020-10-21)
[#15](https://github.com/uehara1414/japanize-matplotlib/pull/15) matplotlibのバージョンが3.2以降の環境の場合、import時にWarningが出てしまう問題を解決 ([@pesuchin](https://github.com/pesuchin))
